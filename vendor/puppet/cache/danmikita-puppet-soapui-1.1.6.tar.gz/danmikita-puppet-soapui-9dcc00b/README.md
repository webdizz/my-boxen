# SoapUI Puppet Module for Boxen

Install [SoapUI](http://www.soapui.org/), a free and open source cross-platform Functional Testing solution.

## Usage

```puppet
include soapui
```

## Required Puppet Modules

* `boxen`

## Development

Write code. Run `script/cibuild` to test it. Check the `script`
directory for other useful tools.
