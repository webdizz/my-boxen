# Aquamacs Puppet Module for Boxen

Install [Aquamacs](http://aquamacs.org/), a modern editor based on GNU Emacs that makes the Mac user feel at home.

## Usage

```puppet
include aquamacs
```

## Required Puppet Modules

* `boxen`

## Development

Write code. Run `script/cibuild` to test it. Check the `script`
directory for other useful tools.
